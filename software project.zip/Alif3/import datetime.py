import datetime

users = {"Alif": "1234", "Zihad": "4321", "Sobuj": "4422"}
admins = {"Linkon": "1122"}
usact = {
    "Alif": {"balance": 2000, "deposits": [], "withdrawal": [], "transfer": []},
    "Zihad": {"balance": 3500, "deposits": [], "withdrawal": [], "transfer": []},
    "Sobuj": {"balance": 1750, "deposits": [], "withdrawal": [], "transfer": []},
}

def main():
    print("     --- Welcome to Section(N) Bank ---\n"
          "           -------------------\n"
          "          **   Bangladesh    ** \n"
          "          |" + str(datetime.datetime.now()).split(".")[0] + "|\n"

          "           -------------------\n")
    print("1. Sign Up\n2. Login\n3. Exit")

    while True:
        ask = input("Which one do you choose?:")
        if ask == "1":
            sign_up(users, usact)
        elif ask == "2":
            login(users)
        elif ask == "3":
            exit()
        else:
            print("Invalid entry. Please enter again")

def sign_up(users, usact):
    print("     --- User Registration ---\n")
    while True:
        username = input("Enter a new username: ")
        if username in users:
            print("Username already exists. Please try another.")
        else:
            password = input("Enter a new password: ")
            users[username] = password
            balance = input("Enter your balance: ")
            usact[username] = {"balance": balance, "deposits": [], "withdrawal": [], "transfer": []}
            print(f"User '{username}' has been successfully registered with an initial balance of 1000 TL.")
            main()


def login(users):
    while True:
        usname = input("Please enter your username:")
        passwrd = input("Please enter your password:")
        if usname not in users:
            print("Invalid username. Please enter again")
        elif passwrd != users[usname]:
            print("Invalid password. Please enter again")
        else:
            print(usname + " Welcome to Sehir Bank.")
            break
    menu(users, usact, usname, passwrd)

def menu(users, usact, usname, passwrd):
    print("Please enter the number of the service\n"
          "1. Withdraw Money\n"
          "2. Deposit Money\n"
          "3. Transfer Money\n"
          "4. My Account Information\n"
          "5. Logout")
    while True:
        ask = input("Please choose a service: ")
        if ask == "1":
            while True:
                wtd = input("Please enter the amount you want to withdraw:")
                if int(wtd) <= usact[usname]["balance"]:
                    usact[usname]["balance"] -= int(wtd)
                    usact[usname]["withdrawal"].append((wtd, str(datetime.datetime.now()).split(".")[0]))
                    print(wtd + "TL withdrawn from your account\n"
                          "Going back to main menu...")
                    menu(users, usact, usname, passwrd)
                else:
                    print("You don't have that much money.")
                    menu(users, usact, usname, passwrd)
        elif ask == "2":
            while True:
                dep = input("Please enter the amount you want to deposit:")
                usact[usname]["balance"] += int(dep)
                usact[usname]["deposits"].append((dep, str(datetime.datetime.now()).split(".")[0]))
                print(dep + "TL added to your account\n"
                            "Going back to main menu...")
                menu(users, usact, usname, passwrd)
        elif ask == "3":
            transfer(users, usact, usname, passwrd)
        elif ask == "4":
            print("--------- Sehir Bank ----------\n"
                  "----- " + str(datetime.datetime.now()).split(".")[0] + " -----\n"
                  "-------------------------------")
            print("Your Name: " + usname)
            print("Your Password: " + passwrd)
            print("Your Balance Amount (TL): " + str(usact[usname]["balance"]))
            print("-------------------------------\n"
                  "User Activities Report:\n\n\n"
                  "Your Withdrawals:\n")
            for i in usact[usname]["withdrawal"]:
                print("     " + i[1] + " " + i[0])
            print("\n\nYour Deposits:\n")
            for i in usact[usname]["deposits"]:
                print("     " + i[1] + " " + i[0])
            print("\n\nYour Transfers:\n")
            for i in usact[usname]["transfer"]:
                print("     " + i[2] + " Transferred to " + i[1] + " " + i[0])
            print("\n\n-------------------------------\n"
                  "Going back to main menu...")
            menu(users, usact, usname, passwrd)
        elif ask == "5":
            print("You are logging out. Thank you for choosing Sehir Bank. Wish to see you again.")
            main()
        else:
            print("Invalid service. Please enter again.")

def transfer(users, usact, usname, passwrd):
    print("Warning: If you want to abort the transfer please enter abort")
    while True:
        trans = input("Please enter the name of the user you want to transfer money to:")
        if trans == "abort":
            print("Going back to main menu...")
            menu(users, usact, usname, passwrd)
        elif trans == usname:
            print("Transferring to yourself is not possible!")
        elif trans not in users:
            print("User does not exist!")
        else:
            amount = input("Please enter the amount you want to transfer:")
            if int(amount) <= usact[usname]["balance"]:
                usact[usname]["balance"] -= int(amount)
                usact[usname]["transfer"].append((amount, trans, str(datetime.datetime.now()).split(".")[0]))
                print("Money transferred successfully.\nGoing back to the menu...")
                menu(users, usact, usname, passwrd)
            else:
                print("Sorry, you don't have enough balance.\n")
                menu(users, usact, usname, passwrd)

def admin(users, usact):
    print("--- Admin Menu ---\n"
          "Please enter a number of the setting operations supported:\n"
          "1. Add User\n"
          "2. Remove User\n"
          "3. Display all Users\n"
          "4. Exit Admin Menu")
    while True:
        select = input("Which operation do you choose?:")
        if select == "1":
            nwus = input("Enter the new username:")
            nwps = input("Enter the new user password:")
            users[nwus] = nwps
            usact[nwus] = {"balance": 5000, "deposits": [], "withdrawal": [], "transfer": []}
            print(nwus + " was added as a user.")
        elif select == "2":
            remove = input("Enter the username to remove:")
            if remove not in users:
                print(remove + " does not exist.")
            else:
                users.pop(remove)
                usact.pop(remove)
                print(remove + " was removed.")
        elif select == "3":
            print("--- List of Users ---")
            for user, pwd in users.items():
                print(f"User: {user}, Password: {pwd}")
        elif select == "4":
            main()
        else:
            print("Invalid entry. Please enter again.")
main()